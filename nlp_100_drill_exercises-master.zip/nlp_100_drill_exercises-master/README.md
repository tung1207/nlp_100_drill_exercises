Thử làm 100 bài tập xử lý ngôn ngữ tự nhiên.

Đề bài và code gốc được thầy Minh dịch từ tài liệu 言語処理100本ノック của lab Inui-Okazaki, đại học Tohoku, Nhật Bản.

github: https://github.com/minhpqn/nlp_100_drill_exercises.

Tham khảo thêm phiên bản cũ (tiếng Nhật) của tài liệu tại http://www.cl.ecei.tohoku.ac.jp/nlp100.


